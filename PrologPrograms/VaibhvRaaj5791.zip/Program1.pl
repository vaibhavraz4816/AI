/* 1. Write a prolog program to calculate the sum of two numbers. */

sum(A, B, C):- 
	C is A + B.